
        1. Scaling mel-spectrogram using log function (10*np.log10(power_sp))
        2. Smooth log mel-spectrogram with Block mathing 3D
        3. Rescaling log mel-spectrogram (np.power(10.0, 0.1 * db_est))
        [bm3d parameters]
        noise_variance:0.004
denoise_residual:True

        